import HomeExperience from "@/components/HomeExperience";

export const metadata = {
  title: "PropSignal | NFL Prop Bets, Projections & Live Game Center",
  description: "See sportsbook lines, PropSignal projections, matchup intelligence, recent form and live NFL game tracking in one place.",
};

export default function HomePage() {
  return <HomeExperience />;
}
