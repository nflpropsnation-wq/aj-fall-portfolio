import PlayerDetail from "@/components/PlayerDetail";

export const dynamic = "force-dynamic";

export default async function PlayerPage({params}:{params:Promise<{slug:string}>}) {
  const {slug}=await params;
  return <PlayerDetail slug={slug}/>;
}
