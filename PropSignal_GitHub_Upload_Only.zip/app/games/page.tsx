import GameCenter from "@/components/GameCenter";

export const dynamic = "force-dynamic";

export const metadata = {
  title: "NFL Live Scores & Game Center | PropSignal",
  description: "Live NFL scores, field position, play-by-play, player stats and live prop tracking.",
};

export default function GamesPage() {
  return <GameCenter />;
}
