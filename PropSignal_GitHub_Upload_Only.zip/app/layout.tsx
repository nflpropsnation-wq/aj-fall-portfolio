import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "PropSignal | NFL Player Prop Intelligence",
  description: "NFL player prop projections, matchup intelligence and live game tracking.",
};

export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return (
    <html lang="en">
      <body>{children}</body>
    </html>
  );
}
