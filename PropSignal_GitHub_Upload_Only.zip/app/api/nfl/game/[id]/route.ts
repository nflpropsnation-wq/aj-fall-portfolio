import { NextResponse } from "next/server";

export const dynamic = "force-dynamic";

type Json = Record<string, any>;

function asNumber(value: unknown) {
  const n = Number(value);
  return Number.isFinite(n) ? n : null;
}

function displayHeadshot(athlete: Json) {
  if (typeof athlete?.headshot === "string") return athlete.headshot;
  return athlete?.headshot?.href || null;
}

function flattenPlays(data: Json) {
  const collected: Json[] = [];
  if (Array.isArray(data?.plays)) collected.push(...data.plays);
  const current = data?.drives?.current;
  if (Array.isArray(current?.plays)) collected.push(...current.plays);
  for (const drive of data?.drives?.previous || []) {
    if (Array.isArray(drive?.plays)) collected.push(...drive.plays);
  }
  const seen = new Set<string>();
  return collected.filter((p: Json) => {
    const key = String(p?.id || `${p?.sequenceNumber || ""}:${p?.text || ""}:${p?.clock?.displayValue || ""}`);
    if (seen.has(key)) return false;
    seen.add(key);
    return true;
  }).sort((a: Json, b: Json) => Number(b?.sequenceNumber || b?.id || 0) - Number(a?.sequenceNumber || a?.id || 0));
}

function yardLine(value: Json) {
  return asNumber(value?.yardLine ?? value?.yard ?? value?.yardline);
}

function mapPlay(play: Json, index: number) {
  return {
    id: String(play?.id || `espn-play-${index}`),
    external_play_id: String(play?.id || `espn-play-${index}`),
    sequence_number: asNumber(play?.sequenceNumber) ?? index,
    period: play?.period?.number ? String(play.period.number) : play?.period ? String(play.period) : null,
    clock: play?.clock?.displayValue || play?.clock || null,
    play_text: play?.text || play?.shortText || play?.type?.text || "Live play",
    scoring_play: Boolean(play?.scoringPlay),
    start_yard_line: yardLine(play?.start),
    end_yard_line: yardLine(play?.end),
    end_down: asNumber(play?.end?.down),
    end_distance: asNumber(play?.end?.distance),
    wallclock: play?.wallclock || null,
    stat_yardage: asNumber(play?.statYardage),
  };
}

function ensurePlayer(map: Map<string, Json>, athlete: Json, teamAbbr: string) {
  const id = String(athlete?.id || athlete?.uid || athlete?.displayName || athlete?.fullName || crypto.randomUUID());
  if (!map.has(id)) {
    map.set(id, {
      player_id: `espn:${id}`,
      provider_player_id: id,
      player_name: athlete?.displayName || athlete?.fullName || athlete?.shortName || "Player",
      position: athlete?.position?.abbreviation || "",
      jersey: athlete?.jersey || null,
      image_url: displayHeadshot(athlete),
      team_abbreviation: teamAbbr,
      passing_completions: null,
      passing_attempts: null,
      passing_yards: null,
      passing_touchdowns: null,
      passing_interceptions: null,
      rushing_attempts: null,
      rushing_yards: null,
      rushing_touchdowns: null,
      receiving_targets: null,
      receptions: null,
      receiving_yards: null,
      receiving_touchdowns: null,
      touchdowns_total: null,
    });
  }
  return map.get(id)!;
}

function indexOfLabel(labels: unknown[], needles: string[]) {
  return labels.findIndex((label) => {
    const s = String(label || "").toUpperCase();
    return needles.some(n => s === n || s.includes(n));
  });
}

function statAt(stats: unknown[], labels: unknown[], needles: string[]) {
  const i = indexOfLabel(labels, needles);
  return i >= 0 ? stats?.[i] : null;
}

function parsePlayers(data: Json) {
  const players = new Map<string, Json>();
  for (const group of data?.boxscore?.players || []) {
    const teamAbbr = group?.team?.abbreviation || group?.team?.shortDisplayName || "";
    for (const category of group?.statistics || []) {
      const name = String(category?.name || "").toLowerCase();
      const labels = category?.labels || category?.names || [];
      for (const row of category?.athletes || []) {
        const athlete = row?.athlete || {};
        const stats = row?.stats || [];
        const p = ensurePlayer(players, athlete, teamAbbr);
        if (name.includes("passing")) {
          const catt = String(statAt(stats, labels, ["C/ATT", "CMP/ATT"]) || "");
          const [cmp, att] = catt.split("/").map(Number);
          if (Number.isFinite(cmp)) p.passing_completions = cmp;
          if (Number.isFinite(att)) p.passing_attempts = att;
          p.passing_yards = asNumber(statAt(stats, labels, ["YDS"]));
          p.passing_touchdowns = asNumber(statAt(stats, labels, ["TD"]));
          p.passing_interceptions = asNumber(statAt(stats, labels, ["INT"]));
        } else if (name.includes("rushing")) {
          p.rushing_attempts = asNumber(statAt(stats, labels, ["CAR", "ATT"]));
          p.rushing_yards = asNumber(statAt(stats, labels, ["YDS"]));
          p.rushing_touchdowns = asNumber(statAt(stats, labels, ["TD"]));
        } else if (name.includes("receiv")) {
          p.receptions = asNumber(statAt(stats, labels, ["REC"]));
          p.receiving_targets = asNumber(statAt(stats, labels, ["TGTS", "TGT"]));
          p.receiving_yards = asNumber(statAt(stats, labels, ["YDS"]));
          p.receiving_touchdowns = asNumber(statAt(stats, labels, ["TD"]));
        }
        p.touchdowns_total = Number(p.passing_touchdowns || 0) + Number(p.rushing_touchdowns || 0) + Number(p.receiving_touchdowns || 0);
      }
    }
  }
  return Array.from(players.values());
}

function parseTeamStats(data: Json) {
  return (data?.boxscore?.teams || []).map((group: Json) => {
    const stats = Object.fromEntries((group?.statistics || []).map((s: Json) => [s?.name || s?.label, s?.displayValue ?? s?.value ?? null]));
    return {
      team_abbreviation: group?.team?.abbreviation || null,
      total_yards: stats.totalYards ?? stats.totalOffensivePlays ?? null,
      net_passing_yards: stats.netPassingYards ?? stats.passingYards ?? null,
      rushing_yards: stats.rushingYards ?? null,
      first_downs: stats.firstDowns ?? null,
      third_down_efficiency: stats.thirdDownEff ?? null,
      turnovers: stats.turnovers ?? null,
      possession_time: stats.possessionTime ?? null,
    };
  });
}

export async function GET(_request: Request, context: { params: Promise<{ id: string }> }) {
  const { id } = await context.params;
  if (!/^\d+$/.test(id)) return NextResponse.json({ error: "Invalid game id" }, { status: 400 });
  try {
    const url = `https://site.api.espn.com/apis/site/v2/sports/football/nfl/summary?event=${encodeURIComponent(id)}`;
    const response = await fetch(url, { headers: { "user-agent": "PropSignal/1.0" }, cache: "no-store" });
    if (!response.ok) throw new Error(`Game summary upstream returned ${response.status}`);
    const data = await response.json();
    const plays = flattenPlays(data).map(mapPlay);
    const players = parsePlayers(data);
    const team_stats = parseTeamStats(data);
    const currentDrive = data?.drives?.current || null;
    return NextResponse.json({
      provider: "espn_fallback",
      generated_at: new Date().toISOString(),
      plays,
      players,
      team_stats,
      drive: currentDrive ? {
        play_count: currentDrive?.offensivePlays ?? currentDrive?.plays?.length ?? null,
        yards: currentDrive?.yards ?? null,
        time_elapsed: currentDrive?.timeElapsed?.displayValue || currentDrive?.timeElapsed || null,
        result: currentDrive?.result || currentDrive?.description || null,
      } : null,
    }, { headers: { "Cache-Control": "no-store, max-age=0" } });
  } catch (error) {
    return NextResponse.json({
      provider: "espn_fallback",
      generated_at: new Date().toISOString(),
      plays: [], players: [], team_stats: [], drive: null,
      error: error instanceof Error ? error.message : "Unknown game detail error",
    }, { status: 502 });
  }
}
