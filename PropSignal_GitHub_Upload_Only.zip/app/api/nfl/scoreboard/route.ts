import { NextResponse } from "next/server";

export const dynamic = "force-dynamic";

const ESPN_SCOREBOARD = "https://site.api.espn.com/apis/site/v2/sports/football/nfl/scoreboard";

type Json = Record<string, any>;

function recordSummary(team: Json) {
  const records = Array.isArray(team?.records) ? team.records : [];
  return records.find((r: Json) => r?.name === "overall")?.summary || records[0]?.summary || null;
}

function teamOf(competition: Json, side: "home" | "away") {
  return (competition?.competitors || []).find((c: Json) => c?.homeAway === side) || null;
}

function mapState(status: Json) {
  const state = status?.type?.state;
  if (state === "in") return "live";
  if (state === "post") return "final";
  return "upcoming";
}

function hex(value: unknown, fallback: string) {
  const raw = String(value || "").replace(/^#/, "").trim();
  return /^[0-9a-fA-F]{6}$/.test(raw) ? `#${raw}` : fallback;
}

function parseSituation(competition: Json) {
  const s = competition?.situation || {};
  const possessionId = s?.possession || null;
  const possession = (competition?.competitors || []).find((c: Json) => String(c?.id) === String(possessionId));
  return {
    down: Number.isFinite(Number(s?.down)) ? Number(s.down) : null,
    distance: Number.isFinite(Number(s?.distance)) ? Number(s.distance) : null,
    field_position: s?.possessionText || s?.downDistanceText || null,
    possession_team_abbreviation: possession?.team?.abbreviation || null,
    possession_team_provider_id: possessionId ? String(possessionId) : null,
  };
}

export async function GET() {
  try {
    const response = await fetch(ESPN_SCOREBOARD, {
      headers: { "user-agent": "PropSignal/1.0" },
      cache: "no-store",
    });
    if (!response.ok) throw new Error(`Scoreboard upstream returned ${response.status}`);
    const data = await response.json();

    const games = (data?.events || []).map((event: Json) => {
      const competition = event?.competitions?.[0] || {};
      const home = teamOf(competition, "home") || {};
      const away = teamOf(competition, "away") || {};
      const status = competition?.status || event?.status || {};
      const situation = parseSituation(competition);
      const broadcasts = (competition?.broadcasts || []).flatMap((b: Json) => b?.names || []);
      const leaders = (competition?.leaders || []).map((group: Json) => {
        const leader = group?.leaders?.[0] || {};
        const athlete = leader?.athlete || {};
        return {
          category: group?.name || null,
          label: group?.shortDisplayName || group?.displayName || null,
          display_value: leader?.displayValue || null,
          player_id: athlete?.id ? String(athlete.id) : null,
          player_name: athlete?.displayName || athlete?.fullName || null,
          player_headshot: athlete?.headshot || null,
          position: athlete?.position?.abbreviation || null,
        };
      });

      return {
        game_id: `espn:${event.id}`,
        provider: "espn_fallback",
        provider_game_id: String(event.id),
        kickoff: event?.date || competition?.date,
        season: event?.season?.year || data?.season?.year || null,
        week: event?.week?.number || data?.week?.number || null,
        game_state: mapState(status),
        status_detail: status?.type?.shortDetail || status?.type?.detail || null,
        quarter: status?.period ? String(status.period) : null,
        clock: status?.displayClock || null,
        home_score: Number(home?.score || 0),
        away_score: Number(away?.score || 0),
        home_team_provider_id: home?.id ? String(home.id) : null,
        away_team_provider_id: away?.id ? String(away.id) : null,
        home_abbreviation: home?.team?.abbreviation || "HOME",
        away_abbreviation: away?.team?.abbreviation || "AWAY",
        home_team: home?.team?.displayName || home?.team?.name || "Home",
        away_team: away?.team?.displayName || away?.team?.name || "Away",
        home_record: recordSummary(home),
        away_record: recordSummary(away),
        home_primary_color: hex(home?.team?.color, "#174466"),
        home_secondary_color: hex(home?.team?.alternateColor, "#91A4B7"),
        away_primary_color: hex(away?.team?.color, "#174466"),
        away_secondary_color: hex(away?.team?.alternateColor, "#91A4B7"),
        broadcast: broadcasts.join(", ") || null,
        venue: competition?.venue?.fullName || null,
        freshness: "live",
        fetched_at: new Date().toISOString(),
        leaders,
        ...situation,
      };
    });

    return NextResponse.json({
      provider: "espn_fallback",
      season: data?.season?.year || null,
      week: data?.week?.number || null,
      generated_at: new Date().toISOString(),
      games,
    }, { headers: { "Cache-Control": "no-store, max-age=0" } });
  } catch (error) {
    return NextResponse.json({
      provider: "espn_fallback",
      generated_at: new Date().toISOString(),
      games: [],
      error: error instanceof Error ? error.message : "Unknown scoreboard error",
    }, { status: 502 });
  }
}
