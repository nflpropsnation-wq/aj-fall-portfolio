import GameCenter from "@/components/GameCenter";

export const dynamic = "force-dynamic";

export const metadata = {
  title: "Live Game Center | PropSignal",
  robots: { index: false, follow: false },
};

export default function GameCenterPage() {
  return <GameCenter />;
}
