import { createClient } from "@supabase/supabase-js";

const supabaseUrl = process.env.NEXT_PUBLIC_SUPABASE_URL || "https://jaxtvvclftsvjtsmfzht.supabase.co";
const supabaseKey = process.env.NEXT_PUBLIC_SUPABASE_PUBLISHABLE_KEY || "sb_publishable_Y6dON0jsMRE_gikQBzTZSw_HAxS4bRb";

export const supabase = createClient(supabaseUrl, supabaseKey, {
  auth: { persistSession: true },
  realtime: { params: { eventsPerSecond: 20 } },
});
