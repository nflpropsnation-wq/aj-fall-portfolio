export type PropEdge = {
  player_id?: string | null;
  player_name: string;
  position: string;
  jersey?: string | null;
  image_url?: string | null;
  team_abbreviation: string;
  team_name?: string | null;
  opponent_abbreviation: string;
  opponent_name?: string | null;
  market: string;
  projection_value: number;
  sportsbook_line: number;
  edge: number;
  signed_edge?: number | null;
  direction: string;
  signal_category?: string | null;
  agreement_score?: number | null;
  input_count?: number | null;
  kickoff?: string | null;
  game_id?: string | null;
};

export const sampleProps: PropEdge[] = [
  {
    player_name: "Odell Beckham Jr.",
    position: "WR",
    jersey: "13",
    image_url: "/players/odell-hero.jpg",
    team_abbreviation: "NYG",
    team_name: "New York Giants",
    opponent_abbreviation: "DAL",
    market: "Receiving Yards",
    projection_value: 84.9,
    sportsbook_line: 67.5,
    edge: 17.4,
    direction: "over",
    signal_category: "Strong",
  },
  {
    player_name: "Josh Allen",
    position: "QB",
    image_url: "https://a.espncdn.com/i/headshots/nfl/players/full/3918298.png",
    jersey: "17",
    team_abbreviation: "BUF",
    team_name: "Buffalo Bills",
    opponent_abbreviation: "MIA",
    market: "Passing Yards",
    projection_value: 272.1,
    sportsbook_line: 244.5,
    edge: 27.6,
    direction: "over",
    signal_category: "Strong",
  },
  {
    player_name: "Saquon Barkley",
    position: "RB",
    image_url: "https://a.espncdn.com/i/headshots/nfl/players/full/3929630.png",
    jersey: "26",
    team_abbreviation: "PHI",
    team_name: "Philadelphia Eagles",
    opponent_abbreviation: "DAL",
    market: "Rushing Yards",
    projection_value: 96.2,
    sportsbook_line: 78.5,
    edge: 17.7,
    direction: "over",
    signal_category: "Strong",
  },
  {
    player_name: "CeeDee Lamb",
    position: "WR",
    image_url: "https://a.espncdn.com/i/headshots/nfl/players/full/4241389.png",
    jersey: "88",
    team_abbreviation: "DAL",
    team_name: "Dallas Cowboys",
    opponent_abbreviation: "PHI",
    market: "Receiving Yards",
    projection_value: 88.4,
    sportsbook_line: 72.5,
    edge: 15.9,
    direction: "over",
    signal_category: "Strong",
  },
  {
    player_name: "Amon-Ra St. Brown",
    position: "WR",
    image_url: "https://a.espncdn.com/i/headshots/nfl/players/full/4374302.png",
    jersey: "14",
    team_abbreviation: "DET",
    team_name: "Detroit Lions",
    opponent_abbreviation: "GB",
    market: "Receptions",
    projection_value: 8.1,
    sportsbook_line: 6.5,
    edge: 1.6,
    direction: "over",
    signal_category: "Strong",
  },
  {
    player_name: "Patrick Mahomes",
    position: "QB",
    image_url: "https://a.espncdn.com/i/headshots/nfl/players/full/3139477.png",
    jersey: "15",
    team_abbreviation: "KC",
    team_name: "Kansas City Chiefs",
    opponent_abbreviation: "MIA",
    market: "Passing Touchdowns",
    projection_value: 2.1,
    sportsbook_line: 1.5,
    edge: 0.6,
    direction: "over",
    signal_category: "Good",
  },
  {
    player_name: "Ja'Marr Chase",
    position: "WR",
    image_url: "https://a.espncdn.com/i/headshots/nfl/players/full/4362628.png",
    jersey: "1",
    team_abbreviation: "CIN",
    team_name: "Cincinnati Bengals",
    opponent_abbreviation: "BAL",
    market: "Receiving Yards",
    projection_value: 98.2,
    sportsbook_line: 76.5,
    edge: 21.7,
    direction: "over",
    signal_category: "Strong",
  },
  {
    player_name: "Christian McCaffrey",
    position: "RB",
    image_url: "https://a.espncdn.com/i/headshots/nfl/players/full/3117251.png",
    jersey: "23",
    team_abbreviation: "SF",
    team_name: "San Francisco 49ers",
    opponent_abbreviation: "ARI",
    market: "Rushing Yards",
    projection_value: 102.6,
    sportsbook_line: 84.5,
    edge: 18.1,
    direction: "over",
    signal_category: "Strong",
  },
  {
    player_name: "Dalton Kincaid",
    position: "TE",
    image_url: "https://a.espncdn.com/i/headshots/nfl/players/full/4385690.png",
    jersey: "86",
    team_abbreviation: "BUF",
    team_name: "Buffalo Bills",
    opponent_abbreviation: "NE",
    market: "Receiving Yards",
    projection_value: 64.2,
    sportsbook_line: 50.5,
    edge: 13.7,
    direction: "over",
    signal_category: "Strong",
  },
];

export const playerDetails: Record<string, {
  matchupGrade: string;
  defenseRank: number;
  dvoa: number;
  paceRank: number;
  recent: number[];
  opponents: string[];
  targetShare: string;
  targetsPerGame: string;
  yardsPerRoute: string;
  airYards: string;
  take: string;
}> = {
  "ja-marr-chase": {
    matchupGrade: "A",
    defenseRank: 29,
    dvoa: 15.3,
    paceRank: 12,
    recent: [102, 85, 62, 107, 90],
    opponents: ["CLE", "LV", "PIT", "NYG", "DAL"],
    targetShare: "32%",
    targetsPerGame: "10.8",
    yardsPerRoute: "2.85",
    airYards: "128.4",
    take: "Chase has cleared this line in 4 of his last 5 games and faces a bottom-3 pass defense in DVOA. Expect high target volume in a fast-paced matchup.",
  },
  "christian-mccaffrey": {
    matchupGrade: "A-",
    defenseRank: 27,
    dvoa: 11.8,
    paceRank: 6,
    recent: [118, 96, 78, 103, 87],
    opponents: ["SEA", "LAR", "ARI", "DAL", "MIA"],
    targetShare: "22%",
    targetsPerGame: "5.7",
    yardsPerRoute: "1.64",
    airYards: "19.4",
    take: "McCaffrey's workload remains elite and the matchup grades favorably. The projection sits well above the market while recent touch volume remains stable.",
  },
  "dalton-kincaid": {
    matchupGrade: "A-",
    defenseRank: 24,
    dvoa: 9.8,
    paceRank: 14,
    recent: [61, 72, 49, 67, 55],
    opponents: ["MIA", "NYJ", "HOU", "IND", "KC"],
    targetShare: "22%",
    targetsPerGame: "7.8",
    yardsPerRoute: "1.95",
    airYards: "54.2",
    take: "Kincaid draws a favorable underneath matchup and projects for strong involvement. The current line leaves room beneath the PropSignal consensus.",
  },
};

export function slugifyPlayer(name: string) {
  return name
    .toLowerCase()
    .replace(/[’']/g, "")
    .replace(/[^a-z0-9]+/g, "-")
    .replace(/^-|-$/g, "");
}

export function displayMarket(market: string) {
  return market.replace(/_/g, " ").replace(/\b\w/g, (c) => c.toUpperCase());
}
