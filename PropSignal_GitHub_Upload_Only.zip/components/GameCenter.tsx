"use client";

import { useCallback, useEffect, useMemo, useState } from "react";
import { useSearchParams } from "next/navigation";
import { supabase } from "@/lib/supabase";
import { getTeam } from "@/lib/teamColors";

type Leader = {
  category?: string | null;
  label?: string | null;
  display_value?: string | null;
  player_id?: string | null;
  player_name?: string | null;
  player_headshot?: string | null;
  position?: string | null;
};

type Game = {
  game_id: string;
  internal_game_id?: string | null;
  provider?: string | null;
  provider_game_id?: string | null;
  kickoff: string;
  season?: number | null;
  week?: number | null;
  game_state: string;
  status_detail?: string | null;
  home_score: number;
  away_score: number;
  home_record?: string | null;
  away_record?: string | null;
  quarter?: string | null;
  clock?: string | null;
  down?: number | null;
  distance?: number | null;
  field_position?: string | null;
  freshness?: string | null;
  fetched_at?: string | null;
  home_team_id?: string | null;
  away_team_id?: string | null;
  possession_team_id?: string | null;
  possession_team_abbreviation?: string | null;
  home_abbreviation: string;
  away_abbreviation: string;
  home_team: string;
  away_team: string;
  home_primary_color?: string | null;
  home_secondary_color?: string | null;
  away_primary_color?: string | null;
  away_secondary_color?: string | null;
  broadcast?: string | null;
  venue?: string | null;
  latest_play_text?: string | null;
  latest_play_scoring?: boolean | null;
  leaders?: Leader[];
  isDemo?: boolean;
};

type Play = {
  id?: string;
  game_id?: string;
  external_play_id?: string;
  sequence_number?: number | null;
  period?: string | null;
  clock?: string | null;
  play_text?: string | null;
  scoring_play?: boolean;
  start_yard_line?: number | null;
  end_yard_line?: number | null;
  end_down?: number | null;
  end_distance?: number | null;
  possession_team_id?: string | null;
  wallclock?: string | null;
  stat_yardage?: number | null;
};

type PlayerStat = {
  player_id: string;
  provider_player_id?: string | null;
  player_name: string;
  position: string;
  jersey?: string | null;
  image_url?: string | null;
  team_abbreviation?: string | null;
  passing_completions?: number | null;
  passing_attempts?: number | null;
  passing_yards?: number | null;
  passing_touchdowns?: number | null;
  passing_interceptions?: number | null;
  rushing_attempts?: number | null;
  rushing_yards?: number | null;
  rushing_touchdowns?: number | null;
  receptions?: number | null;
  receiving_targets?: number | null;
  receiving_yards?: number | null;
  receiving_touchdowns?: number | null;
  touchdowns_total?: number | null;
};

type TeamStat = {
  team_abbreviation?: string | null;
  total_yards?: string | number | null;
  net_passing_yards?: string | number | null;
  rushing_yards?: string | number | null;
  first_downs?: string | number | null;
  third_down_efficiency?: string | number | null;
  turnovers?: string | number | null;
  possession_time?: string | number | null;
};

type Prop = {
  player_id: string;
  player_name: string;
  team_abbreviation?: string | null;
  market: string;
  direction: string;
  sportsbook_line: number;
  projection_value: number;
  edge: number;
  signal_category?: string | null;
  live_value?: number | null;
};

type SocialPost = {
  id?: string;
  author_handle?: string | null;
  author_name?: string | null;
  account_type?: string | null;
  posted_at?: string | null;
  post_text?: string | null;
  trusted?: boolean;
  prop_impact?: unknown;
};

type Drive = { play_count?: number | null; yards?: number | null; time_elapsed?: string | null; result?: string | null } | null;

type Filter = "all" | "live" | "upcoming" | "final";

const demoGames: Game[] = [
  {game_id:"demo-buf-ne",kickoff:"2026-09-27T17:00:00Z",season:2026,week:3,game_state:"live",home_score:17,away_score:24,quarter:"3",clock:"08:42",down:1,distance:10,field_position:"BUF 42",freshness:"live",home_abbreviation:"NE",away_abbreviation:"BUF",home_team:"New England Patriots",away_team:"Buffalo Bills",home_record:"3-10",away_record:"9-4",home_primary_color:"#002244",home_secondary_color:"#C60C30",away_primary_color:"#00338D",away_secondary_color:"#C60C30",latest_play_text:"Josh Allen pass complete to Dalton Kincaid for 14 yards.",isDemo:true},
  {game_id:"demo-kc-mia",kickoff:"2026-09-27T17:00:00Z",season:2026,week:3,game_state:"upcoming",home_score:0,away_score:0,home_abbreviation:"MIA",away_abbreviation:"KC",home_team:"Miami Dolphins",away_team:"Kansas City Chiefs",isDemo:true},
  {game_id:"demo-bal-dal",kickoff:"2026-09-27T20:25:00Z",season:2026,week:3,game_state:"upcoming",home_score:0,away_score:0,home_abbreviation:"DAL",away_abbreviation:"BAL",home_team:"Dallas Cowboys",away_team:"Baltimore Ravens",isDemo:true},
  {game_id:"demo-la-den",kickoff:"2026-09-28T00:20:00Z",season:2026,week:3,game_state:"upcoming",home_score:0,away_score:0,home_abbreviation:"DEN",away_abbreviation:"LA",home_team:"Denver Broncos",away_team:"Los Angeles Rams",isDemo:true},
];

const demoPlays: Play[] = [
  {external_play_id:"d1",sequence_number:4,period:"3",clock:"08:42",play_text:"Josh Allen pass complete to Dalton Kincaid for 14 yards.",scoring_play:false,start_yard_line:28,end_yard_line:42,end_down:1,end_distance:10},
  {external_play_id:"d2",sequence_number:3,period:"3",clock:"09:15",play_text:"James Cook rush for 6 yards.",start_yard_line:22,end_yard_line:28,end_down:2,end_distance:4},
  {external_play_id:"d3",sequence_number:2,period:"3",clock:"09:48",play_text:"Incomplete pass intended for Khalil Shakir.",start_yard_line:22,end_yard_line:22,end_down:2,end_distance:10},
  {external_play_id:"d4",sequence_number:1,period:"3",clock:"10:21",play_text:"Josh Allen pass to Keon Coleman for 8 yards.",start_yard_line:14,end_yard_line:22,end_down:1,end_distance:10},
];

const demoStats: PlayerStat[] = [
  {player_id:"demo-ja",player_name:"Josh Allen",position:"QB",jersey:"17",team_abbreviation:"BUF",passing_completions:18,passing_attempts:25,passing_yards:218,rushing_yards:34,image_url:"/demo/qb-demo.png"},
  {player_id:"demo-dk",player_name:"Dalton Kincaid",position:"TE",jersey:"86",team_abbreviation:"BUF",receptions:5,receiving_targets:7,receiving_yards:62,image_url:"/demo/te-demo.png"},
  {player_id:"demo-jc",player_name:"James Cook",position:"RB",jersey:"4",team_abbreviation:"BUF",rushing_attempts:15,rushing_yards:88},
  {player_id:"demo-ks",player_name:"Khalil Shakir",position:"WR",jersey:"10",team_abbreviation:"BUF",receptions:4,receiving_yards:54},
];

const demoProps: Prop[] = [
  {player_id:"demo-dk",player_name:"Dalton Kincaid",team_abbreviation:"BUF",market:"Receiving Yards",direction:"over",sportsbook_line:50.5,projection_value:63.8,edge:13.3,signal_category:"Solid",live_value:47},
  {player_id:"demo-jc",player_name:"James Cook",team_abbreviation:"BUF",market:"Rushing Yards",direction:"over",sportsbook_line:74.5,projection_value:91.1,edge:16.6,signal_category:"Strong",live_value:68},
  {player_id:"demo-ja",player_name:"Josh Allen",team_abbreviation:"BUF",market:"Passing Yards",direction:"over",sportsbook_line:244.5,projection_value:271.2,edge:26.7,signal_category:"Hammer",live_value:218},
];

const demoSocial: SocialPost[] = [
  {id:"x1",author_name:"Official Team Account",author_handle:"team",account_type:"team",trusted:true,posted_at:new Date().toISOString(),post_text:"Big conversion keeps the drive alive in opponent territory."},
  {id:"x2",author_name:"NFL Reporter",author_handle:"reporter",account_type:"reporter",trusted:true,posted_at:new Date(Date.now()-60000).toISOString(),post_text:"The short passing game is creating repeated opportunities for the tight end.",prop_impact:{summary:"TE targets trending upward"}},
];

function kickoffLabel(kickoff: string, long = false) {
  try {
    return new Intl.DateTimeFormat("en-US", long ? {weekday:"short",month:"short",day:"numeric",hour:"numeric",minute:"2-digit"} : {weekday:"short",hour:"numeric",minute:"2-digit"}).format(new Date(kickoff));
  } catch { return "Scheduled"; }
}

function quarterLabel(q?: string | null) {
  const n = Number(q);
  if (!Number.isFinite(n)) return q || "LIVE";
  if (n === 1) return "1ST QUARTER";
  if (n === 2) return "2ND QUARTER";
  if (n === 3) return "3RD QUARTER";
  if (n === 4) return "4TH QUARTER";
  return `Q${n}`;
}

function ordinal(n?: number | null) {
  if (!n) return "1st";
  if (n === 1) return "1st";
  if (n === 2) return "2nd";
  if (n === 3) return "3rd";
  return `${n}th`;
}

function parseYardLine(value?: string | null, fallback = 42) {
  if (!value) return fallback;
  const matches = value.match(/\d+/g);
  const n = Number(matches?.[matches.length - 1]);
  return Number.isFinite(n) ? Math.min(50, Math.max(1, n)) : fallback;
}

function sameMatchup(a: Game, b: Game) {
  if (a.home_abbreviation !== b.home_abbreviation || a.away_abbreviation !== b.away_abbreviation) return false;
  const at = new Date(a.kickoff).getTime(), bt = new Date(b.kickoff).getTime();
  return Number.isFinite(at) && Number.isFinite(bt) ? Math.abs(at-bt) < 12*60*60*1000 : true;
}

function statValueForProp(prop: Prop, stats: PlayerStat[]) {
  if (prop.live_value != null) return Number(prop.live_value);
  const s = stats.find(x => x.player_id === prop.player_id);
  if (!s) return 0;
  const m = prop.market.toLowerCase();
  if (m.includes("passing") && m.includes("yard")) return Number(s.passing_yards || 0);
  if (m.includes("rushing") && m.includes("yard")) return Number(s.rushing_yards || 0);
  if (m.includes("receiv") && m.includes("yard")) return Number(s.receiving_yards || 0);
  if (m.includes("reception")) return Number(s.receptions || 0);
  return Number(s.touchdowns_total || 0);
}

function chooseDefault(games: Game[]) {
  return games.find(g=>g.game_state === "live") || games.find(g=>g.game_state === "upcoming") || games[0];
}

function PlayerPhoto({player,size="lg"}:{player?:PlayerStat;size?:"sm"|"lg"}) {
  const cls = size === "sm" ? "player-photo small" : "player-photo";
  if (player?.image_url) {
    return <div className={cls}><img src={player.image_url} alt={player.player_name} loading="lazy" referrerPolicy="no-referrer" /></div>;
  }
  const initials = player?.player_name?.split(" ").map(x=>x[0]).slice(0,2).join("") || "PS";
  return <div className={`${cls} photo-fallback`}><span>{initials}</span></div>;
}

export default function GameCenter() {
  const searchParams = useSearchParams();
  const requestedGame = searchParams.get("game");
  const [games,setGames] = useState<Game[]>(demoGames);
  const [selectedId,setSelectedId] = useState(demoGames[0].game_id);
  const [plays,setPlays] = useState<Play[]>(demoPlays);
  const [stats,setStats] = useState<PlayerStat[]>(demoStats);
  const [teamStats,setTeamStats] = useState<TeamStat[]>([]);
  const [props,setProps] = useState<Prop[]>(demoProps);
  const [social,setSocial] = useState<SocialPost[]>(demoSocial);
  const [drive,setDrive] = useState<Drive>({play_count:7,yards:68,time_elapsed:"4:21"});
  const [tab,setTab] = useState("center");
  const [filter,setFilter] = useState<Filter>("all");
  const [connected,setConnected] = useState(false);
  const [sourceLabel,setSourceLabel] = useState("DEMO");
  const [message,setMessage] = useState("Loading the current NFL slate…");
  const [week,setWeek] = useState<number>(3);

  const selected = useMemo(() => games.find(g=>g.game_id===selectedId) || games[0], [games,selectedId]);
  const filteredGames = useMemo(()=>filter === "all" ? games : games.filter(g=>g.game_state === filter),[games,filter]);
  const liveCount = games.filter(g=>g.game_state === "live").length;
  const upcomingCount = games.filter(g=>g.game_state === "upcoming").length;
  const finalCount = games.filter(g=>g.game_state === "final").length;

  const fetchGames = useCallback(async()=>{
    const from = new Date(Date.now()-7*24*60*60*1000).toISOString();
    const to = new Date(Date.now()+10*24*60*60*1000).toISOString();
    const [scoreboardResult, supabaseResult] = await Promise.allSettled([
      fetch("/api/nfl/scoreboard", {cache:"no-store"}).then(r=>r.ok?r.json():Promise.reject(new Error(`scoreboard ${r.status}`))),
      supabase.from("live_game_center").select("*").gte("kickoff",from).lte("kickoff",to).order("kickoff",{ascending:true}).limit(40),
    ]);

    const sbRows = supabaseResult.status === "fulfilled" && !supabaseResult.value.error ? (supabaseResult.value.data || []) as unknown as Game[] : [];
    const webRows = scoreboardResult.status === "fulfilled" ? (scoreboardResult.value.games || []) as Game[] : [];
    const currentWeek = scoreboardResult.status === "fulfilled" ? Number(scoreboardResult.value.week || 0) : 0;
    if (currentWeek) setWeek(currentWeek);

    if (webRows.length) {
      const merged = webRows.map(webGame=>{
        const internal = sbRows.find(row=>sameMatchup(webGame,row));
        if (!internal) return webGame;
        const internalIsFresh = ["live","delayed"].includes(String(internal.freshness || ""));
        return {
          ...webGame,
          internal_game_id: internal.game_id,
          ...(internalIsFresh ? {
            home_score: internal.home_score,
            away_score: internal.away_score,
            quarter: internal.quarter || webGame.quarter,
            clock: internal.clock || webGame.clock,
            down: internal.down ?? webGame.down,
            distance: internal.distance ?? webGame.distance,
            field_position: internal.field_position || webGame.field_position,
            possession_team_id: internal.possession_team_id,
            freshness: internal.freshness,
            fetched_at: internal.fetched_at,
            latest_play_text: internal.latest_play_text || webGame.latest_play_text,
          } : {}),
        };
      });
      setGames(merged);
      setSelectedId(id=>merged.some(g=>g.game_id===id)?id:(chooseDefault(merged)?.game_id || merged[0].game_id));
      setConnected(true);
      setSourceLabel(sbRows.some(r=>["live","delayed"].includes(String(r.freshness))) ? "HYBRID LIVE" : "LIVE SCORE FEED");
      setMessage(sbRows.some(r=>["live","delayed"].includes(String(r.freshness))) ? "PropSignal live backend connected; public score feed is available as a resilience layer." : "Live scoreboard fallback is active. Ball Don’t Lie takes over play-by-play when its production key is installed.");
      return;
    }

    if (sbRows.length) {
      setGames(sbRows);
      setSelectedId(id=>sbRows.some(g=>g.game_id===id)?id:(chooseDefault(sbRows)?.game_id || sbRows[0].game_id));
      setConnected(true);
      setSourceLabel("PROPSIGNAL LIVE");
      setMessage("Connected to the PropSignal live database.");
      return;
    }

    setGames(demoGames);
    setSelectedId(id=>demoGames.some(g=>g.game_id===id)?id:demoGames[0].game_id);
    setConnected(false);
    setSourceLabel("DEMO");
    setMessage("Live providers are unavailable right now, so the interface is showing demo data.");
  },[]);

  const fetchDetail = useCallback(async(game:Game)=>{
    if (game.isDemo) {
      setPlays(demoPlays); setStats(demoStats); setTeamStats([]); setProps(demoProps); setSocial(demoSocial); setDrive({play_count:7,yards:68,time_elapsed:"4:21"}); return;
    }

    const internalId = game.internal_game_id || (game.provider !== "espn_fallback" ? game.game_id : null);
    const detailPromise = game.provider_game_id ? fetch(`/api/nfl/game/${encodeURIComponent(game.provider_game_id)}`,{cache:"no-store"}).then(r=>r.ok?r.json():null).catch(()=>null) : Promise.resolve(null);
    const supabasePromise = internalId ? Promise.all([
      supabase.from("game_plays").select("id,game_id,external_play_id,sequence_number,period,clock,play_text,scoring_play,start_yard_line,end_yard_line,end_down,end_distance,possession_team_id,wallclock,stat_yardage").eq("game_id",internalId).order("sequence_number",{ascending:false}).limit(40),
      supabase.from("game_center_player_stats").select("*").eq("game_id",internalId),
      supabase.from("live_prop_progress").select("*").eq("game_id",internalId).order("edge",{ascending:false}).limit(12),
      supabase.from("live_game_social_feed").select("*").eq("game_id",internalId).order("posted_at",{ascending:false}).limit(20),
    ]) : Promise.resolve(null);

    const [detail, sb] = await Promise.all([detailPromise,supabasePromise]);
    const sbPlays = sb?.[0]?.data as Play[] | null | undefined;
    const sbStats = sb?.[1]?.data as PlayerStat[] | null | undefined;
    const detailPlays = (detail?.plays || []) as Play[];
    const detailPlayers = (detail?.players || []) as PlayerStat[];
    setPlays(sbPlays?.length ? sbPlays : detailPlays);
    setStats(sbStats?.length ? sbStats : detailPlayers);
    setTeamStats((detail?.team_stats || []) as TeamStat[]);
    setDrive((detail?.drive || null) as Drive);
    setProps(((sb?.[2]?.data || []) as Prop[]));
    setSocial(((sb?.[3]?.data || []) as SocialPost[]));
  },[]);

  useEffect(()=>{ fetchGames(); },[fetchGames]);
  useEffect(()=>{
    if (!requestedGame) return;
    const match = games.find(g=>g.game_id===requestedGame || g.provider_game_id===requestedGame || g.internal_game_id===requestedGame);
    if (match && match.game_id!==selectedId) setSelectedId(match.game_id);
  },[requestedGame,games,selectedId]);
  useEffect(()=>{ if(selected) fetchDetail(selected); },[selected,fetchDetail]);

  useEffect(()=>{
    if (!selected) return;
    const live = selected.game_state === "live";
    const every = live ? 15000 : 60000;
    const timer = window.setInterval(()=>{ fetchGames(); if (live) fetchDetail(selected); }, every);
    return ()=>window.clearInterval(timer);
  },[selected,fetchGames,fetchDetail]);

  useEffect(()=>{
    const internalId = selected?.internal_game_id || (selected?.provider !== "espn_fallback" ? selected?.game_id : null);
    if (!selected || selected.isDemo || !internalId) return;
    const channel = supabase.channel(`game-center-${internalId}`)
      .on("postgres_changes",{event:"UPDATE",schema:"public",table:"games",filter:`id=eq.${internalId}`},()=>fetchGames())
      .on("postgres_changes",{event:"*",schema:"public",table:"game_plays",filter:`game_id=eq.${internalId}`},()=>fetchDetail(selected))
      .on("postgres_changes",{event:"*",schema:"public",table:"live_player_stats",filter:`game_id=eq.${internalId}`},()=>fetchDetail(selected))
      .on("postgres_changes",{event:"*",schema:"public",table:"game_social_posts",filter:`game_id=eq.${internalId}`},()=>fetchDetail(selected))
      .subscribe();
    return ()=>{ supabase.removeChannel(channel); };
  },[selected,fetchDetail,fetchGames]);

  if (!selected) return null;

  const awayFallback = getTeam(selected.away_abbreviation);
  const homeFallback = getTeam(selected.home_abbreviation);
  const awayColor = selected.away_primary_color || awayFallback.primary;
  const awaySecondary = selected.away_secondary_color || awayFallback.secondary;
  const homeColor = selected.home_primary_color || homeFallback.primary;
  const homeSecondary = selected.home_secondary_color || homeFallback.secondary;
  const live = selected.game_state === "live";
  const final = selected.game_state === "final";
  const latest = plays[0];
  const yard = parseYardLine(selected.field_position,42);
  const ballPct = Math.max(15,Math.min(85,10 + yard*.8));
  const firstPct = Math.min(87,ballPct + 7.5);
  const offenseAbbr = selected.possession_team_abbreviation || (selected.possession_team_id && selected.possession_team_id===selected.home_team_id ? selected.home_abbreviation : selected.away_abbreviation);
  const topPlayers = stats.filter(x=>[selected.away_abbreviation,selected.home_abbreviation].includes(x.team_abbreviation || ""));
  const featuredQB = topPlayers.find(x=>x.position==="QB") || demoStats[0];
  const featuredReceiver = topPlayers.find(x=>["TE","WR"].includes(x.position) && Number(x.receiving_yards || 0)>0) || topPlayers.find(x=>x.position==="TE") || topPlayers.find(x=>x.position==="WR") || demoStats[1];
  const awayTeamStat = teamStats.find(x=>x.team_abbreviation===selected.away_abbreviation);
  const homeTeamStat = teamStats.find(x=>x.team_abbreviation===selected.home_abbreviation);
  const drivePlays = drive?.play_count ?? Math.max(plays.slice(0,7).length,1);
  const driveYards = drive?.yards ?? Math.max(14,Math.abs((latest?.end_yard_line || 42)-(latest?.start_yard_line || 28)));

  return (
    <main className="game-app scores-hub-app" style={{"--away":awayColor,"--away2":awaySecondary,"--home":homeColor,"--home2":homeSecondary} as React.CSSProperties}>
      <header className="game-nav">
        <div className="nav-inner">
          <a className="game-brand-link" href="/"><img className="game-brand-image" src="/brand/propsignal-logo.jpg" alt="PropSignal" /></a>
          <nav className="nav-links"><a href="/" className="active">NFL</a><a href="/games">Live Games</a><a href="/#props">Player Props</a><a href="/#props">Projections</a><a href="/#research">Insights</a><a href="/#methodology">More</a></nav>
          <div className="hub-search" aria-label="Search placeholder">⌕ &nbsp; Search players, teams, props…</div>
          <div className="nav-actions"><button aria-label="Account">●</button></div>
        </div>
      </header>

      <section className="scores-hero">
        <div className="hero-noise"/>
        <div className="hero-copy"><span className="hero-kicker">NFL</span><h1>WEEK {week}</h1><p>LIVE SCORES &amp; PROPS</p></div>
        <div className="hero-controls">
          <div className="hero-date">NFL • WEEK {week}</div>
          <div className="score-filters" role="group" aria-label="Game filters">
            {([['all','All Games',games.length],['live','Live',liveCount],['upcoming','Upcoming',upcomingCount],['final','Final',finalCount]] as [Filter,string,number][]).map(([id,label,count])=><button key={id} className={filter===id?'active':''} onClick={()=>setFilter(id)}>{label} <span>{count}</span></button>)}
          </div>
        </div>
      </section>

      <section className="game-shell scores-shell">
        <div className="game-strip top-score-strip" role="list" aria-label="NFL games">
          {(filteredGames.length?filteredGames:games).slice(0,10).map(g=><ScoreChip key={g.game_id} game={g} selected={g.game_id===selected.game_id} onClick={()=>setSelectedId(g.game_id)}/>) }
        </div>

        <div className="scores-grid">
          <aside className="week-scoreboard panel-shell">
            <div className="week-title"><strong>NFL Week {week}</strong><span>⌄</span></div>
            <p className="week-date">Current slate</p>
            <div className="week-games-list">
              {(filteredGames.length?filteredGames:games).map(g=><WeekGame key={g.game_id} game={g} selected={g.game_id===selected.game_id} onClick={()=>setSelectedId(g.game_id)}/>) }
            </div>
            <div className="feed-status"><span className={connected?"status-dot live":"status-dot"}/><div><b>{sourceLabel}</b><small>{message}</small></div></div>
          </aside>

          <div className="game-detail-column">
            <section className="scoreboard-card compact-scoreboard">
              <div className="team-side away-side"><div className="team-mark away-mark">{selected.away_abbreviation}</div><div className="team-copy"><small>{awayFallback.city.toUpperCase()}</small><strong>{awayFallback.name.toUpperCase()}</strong><span>{selected.away_record || '—'}</span></div><div className="score">{selected.away_score}</div></div>
              <div className="clock-card"><small>{live?quarterLabel(selected.quarter):final?"FINAL":"NEXT GAME"}</small><strong>{live?(selected.clock || "LIVE"):final?"FINAL":kickoffLabel(selected.kickoff)}</strong><span>{live?`${ordinal(selected.down)} & ${selected.distance || 10}  |  ${selected.field_position || "MIDFIELD"}`:(selected.broadcast || "GAME CENTER READY")}</span><em>{live?`▶ ${offenseAbbr} BALL`:final?"COMPLETE":"PREGAME"}</em></div>
              <div className="team-side home-side"><div className="score">{selected.home_score}</div><div className="team-copy"><small>{homeFallback.city.toUpperCase()}</small><strong>{homeFallback.name.toUpperCase()}</strong><span>{selected.home_record || '—'}</span></div><div className="team-mark home-mark">{selected.home_abbreviation}</div></div>
            </section>

            <div className="game-tabs" role="tablist" aria-label="Game Center views">
              {[['center','Game Center'],['plays','Play-by-Play'],['stats','Player Stats'],['props','Props'],['highlights','Highlights'],['x','Game Conversation']].map(([id,label])=><button key={id} role="tab" aria-selected={tab===id} onClick={()=>setTab(id)}>{label}</button>)}
            </div>

            {tab==="center" && <section className="center-layout">
              <div className="field-panel main-focus-field">
                <div className="stadium-field">
                  <div className="crowd-strip top-crowd"/><div className="crowd-strip bottom-crowd"/>
                  <div className="end-zone away-end">{awayFallback.name.toUpperCase()}</div>
                  <div className="end-zone home-end">{homeFallback.name.toUpperCase()}</div>
                  <div className="field-turf">
                    {[18,26,34,42,50,58,66,74,82].map(x=><i key={x} className="yard-line" style={{left:`${x}%`}}/>) }
                    <div className="yard-numbers top"><span>10</span><span>20</span><span>30</span><span>40</span><span>50</span><span>40</span><span>30</span><span>20</span><span>10</span></div>
                    <div className="yard-numbers bottom"><span>10</span><span>20</span><span>30</span><span>40</span><span>50</span><span>40</span><span>30</span><span>20</span><span>10</span></div>
                    <div className="hashes h1"/><div className="hashes h2"/>
                    <div className="line-of-scrimmage" style={{left:`${ballPct}%`}}/><div className="first-down-line" style={{left:`${firstPct}%`}}/>
                    <div className="drive-trail" style={{left:`${Math.max(14,ballPct-9)}%`,width:"9%"}}/><div className="football-marker" style={{left:`${ballPct}%`}}><span>◆</span></div><div className="field-spot" style={{left:`${ballPct}%`}}>{selected.field_position || `${offenseAbbr} ${yard}`}</div>
                  </div>
                </div>
                <div className="field-legend"><span><i className="dot blue-dot"/>Line of Scrimmage</span><span><i className="dot yellow-dot"/>First Down</span><span>🏈 Ball Position</span><span className="direction">➤ Direction of Possession →</span></div>
              </div>
              <aside className="drive-card"><strong>{ordinal(selected.down)} &amp; {selected.distance || 10}</strong><b>{selected.field_position || `${offenseAbbr} ${yard}`}</b><span>{selected.distance || 10} yards to go</span><hr/><small>DRIVE</small><b>{drivePlays} PLAYS</b><b>{driveYards} YARDS</b><span>{drive?.time_elapsed || (live?"Live drive":"Pregame")}</span><hr/><div className="drive-bottom"><small>RED ZONE</small><span>{yard<=20?"Yes":"No"}</span></div></aside>

              <div className="lower-grid latest-play-card">
                <div className="section-title"><strong>Latest Play</strong><span>{latest?.clock || selected.clock || "--:--"} • {quarterLabel(latest?.period || selected.quarter)}</span></div>
                <div className="latest-play-feature">
                  <div className="portrait-column"><PlayerPhoto player={featuredQB}/><div><b>{featuredQB.player_name}</b><small>{featuredQB.position}{featuredQB.jersey?` #${featuredQB.jersey}`:""}</small></div></div>
                  <div className="latest-play-copy"><p>{latest?.play_text || selected.latest_play_text || (live?"Waiting for the next live play.":final?"Game complete.":"Game has not started yet.")}</p>{live && <span className="first-badge">LIVE PLAY</span>}<small>{selected.field_position || selected.venue || "Field position pending"}</small></div>
                  <div className="portrait-column right"><PlayerPhoto player={featuredReceiver}/><div><b>{featuredReceiver.player_name}</b><small>{featuredReceiver.position}{featuredReceiver.jersey?` #${featuredReceiver.jersey}`:""}</small></div></div>
                </div>
              </div>

              <div className="lower-grid recent-plays-card">
                <div className="section-title"><strong>Recent Plays</strong><button onClick={()=>setTab('plays')}>View All</button></div>
                <div className="recent-list">{plays.length?plays.slice(0,4).map((p,i)=><div className="recent-row" key={p.external_play_id || i}><time>{p.clock || "--:--"}</time><PlayerPhoto player={i===0?featuredReceiver:featuredQB} size="sm"/><div><b>{p.play_text || "Live play"}</b><small>{p.end_down?`${ordinal(p.end_down)} & ${p.end_distance ?? 10}`:"Live update"}</small></div></div>):<Empty compact text={live?"Waiting for the next play…":final?"Play feed unavailable for this game.":"Play-by-play starts at kickoff."}/>}</div>
              </div>

              <TeamKeyStats title={`${selected.away_abbreviation} Key Stats`} score={selected.away_score} stats={stats.filter(s=>s.team_abbreviation===selected.away_abbreviation)} external={awayTeamStat} side="away"/>
              <TeamKeyStats title={`${selected.home_abbreviation} Key Stats`} score={selected.home_score} stats={stats.filter(s=>s.team_abbreviation===selected.home_abbreviation)} external={homeTeamStat} side="home"/>
            </section>}

            {tab==="plays" && <Panel title="Play-by-Play"><div className="full-play-list">{plays.length?plays.map((p,i)=><div className="full-play" key={p.external_play_id || i}><time>{p.clock || "--:--"}<small>{quarterLabel(p.period)}</small></time><div><b>{p.play_text || "Live play"}</b><span>{p.scoring_play?"SCORING PLAY":p.end_down?`${ordinal(p.end_down)} & ${p.end_distance ?? 10}`:""}</span></div></div>):<Empty text="Play-by-play will appear here as the live game feed updates."/>}</div></Panel>}

            {tab==="stats" && <Panel title="Player Stats"><div className="stats-table"><div className="stats-head"><span>Player</span><span>Pass</span><span>Rush</span><span>Receiving</span></div>{stats.length?stats.map(s=><div className="stats-row" key={s.player_id}><div className="player-cell"><PlayerPhoto player={s} size="sm"/><div><b>{s.player_name}</b><small>{s.position} • {s.team_abbreviation}</small></div></div><span>{s.passing_yards?`${s.passing_completions || 0}/${s.passing_attempts || 0} • ${s.passing_yards} YDS`:'—'}</span><span>{s.rushing_yards?`${s.rushing_attempts || 0} CAR • ${s.rushing_yards} YDS`:'—'}</span><span>{s.receiving_yards?`${s.receptions || 0} REC • ${s.receiving_yards} YDS`:'—'}</span></div>):<Empty text="Live player stats will populate once the game feed is active."/>}</div></Panel>}

            {tab==="props" && <Panel title="PropSignal Live Props" kicker="LIVE PROP TRACKER"><div className="props-grid">{props.length?props.map((p,i)=>{const liveValue=statValueForProp(p,stats);const needed=Math.max(0,Math.floor(p.sportsbook_line-liveValue)+1);const progress=Math.max(0,Math.min(100,(liveValue/Math.max(1,p.sportsbook_line))*100));return <article className="prop-live-card" key={`${p.player_id}-${p.market}-${i}`}><div className="prop-top"><div><b>{p.player_name}</b><small>{p.market} • {p.direction.toUpperCase()} {p.sportsbook_line}</small></div><div><strong>{liveValue}</strong><small>LIVE</small></div></div><div className="prop-progress"><i style={{width:`${progress}%`}}/></div><div className="prop-bottom"><span>Projection <b>{p.projection_value}</b></span><span>Edge <b>{Number(p.edge)>=0?'+':''}{Number(p.edge).toFixed(1)}</b></span><strong>{needed?`Needs ${needed} more`:'LINE CLEARED'}</strong></div></article>}):<Empty text="Tracked PropSignal props appear here when a verified starter, current line and live stat overlap."/>}</div></Panel>}

            {tab==="highlights" && <Panel title="Highlights"><Empty text="Highlight slots are ready. Existing Highlightly clips can be mapped once current game IDs are synchronized."/></Panel>}

            {tab==="x" && <Panel title="Game Conversation" kicker="X LIVE"><div className="social-list">{social.length?social.map((x,i)=><article key={x.id || i}><div className="social-meta"><b>{x.author_name || x.author_handle || "Source"}{x.trusted?" ✓":""}</b><time>{x.posted_at?relativeTime(x.posted_at):"Now"}</time></div><p>{x.post_text}</p>{x.prop_impact && <span className="prop-impact">PROP IMPACT: live player context changed</span>}</article>):<Empty text="Curated X posts appear here when the X ingestion connection is enabled."/>}</div></Panel>}
          </div>
        </div>
      </section>
    </main>
  );
}

function relativeTime(value:string) {
  const minutes = Math.round((new Date(value).getTime()-Date.now())/60000);
  if (minutes <= -60) return `${Math.abs(Math.round(minutes/60))}h`;
  if (minutes < 0) return `${Math.abs(minutes)}m`;
  return "Now";
}

function ScoreChip({game,selected,onClick}:{game:Game;selected:boolean;onClick:()=>void}) {
  const live = game.game_state === "live", final = game.game_state === "final";
  return <button role="listitem" className={`score-chip ${selected?"selected":""} ${live?"live":""}`} onClick={onClick}>
    <div className="score-chip-top"><span className={live?"mini-live":""}>{live?"LIVE":final?"FINAL":kickoffLabel(game.kickoff)}</span>{live&&<span>{game.quarter?`Q${game.quarter}`:""} {game.clock}</span>}</div>
    <div className="score-chip-team"><TeamDot abbr={game.away_abbreviation} color={game.away_primary_color}/><b>{game.away_abbreviation}</b><strong>{live||final?game.away_score:""}</strong></div>
    <div className="score-chip-team"><TeamDot abbr={game.home_abbreviation} color={game.home_primary_color}/><b>{game.home_abbreviation}</b><strong>{live||final?game.home_score:""}</strong></div>
    <small>{live?`${ordinal(game.down)} & ${game.distance || 10} • ${game.field_position || "LIVE"}`:(game.broadcast || game.status_detail || "Game Center")}</small>
  </button>;
}

function WeekGame({game,selected,onClick}:{game:Game;selected:boolean;onClick:()=>void}) {
  const live = game.game_state === "live", final = game.game_state === "final";
  return <button className={`week-game ${selected?"selected":""}`} onClick={onClick}>
    <div className="week-game-status">{live?<span className="mini-live">● LIVE</span>:final?<span>FINAL</span>:<span>{kickoffLabel(game.kickoff)}</span>}</div>
    <div className="week-game-team"><TeamDot abbr={game.away_abbreviation} color={game.away_primary_color}/><b>{game.away_abbreviation}</b><span>{game.away_record || ""}</span><strong>{live||final?game.away_score:""}</strong></div>
    <div className="week-game-team"><TeamDot abbr={game.home_abbreviation} color={game.home_primary_color}/><b>{game.home_abbreviation}</b><span>{game.home_record || ""}</span><strong>{live||final?game.home_score:""}</strong></div>
    <i>›</i>
  </button>;
}

function TeamDot({abbr,color}:{abbr:string;color?:string|null}) {
  const c = color || getTeam(abbr).primary;
  return <span className="team-dot" style={{background:`linear-gradient(145deg,${c},color-mix(in srgb,${c} 65%,white))`}}>{abbr}</span>;
}

function Panel({title,kicker,children}:{title:string;kicker?:string;children:React.ReactNode}) {
  return <section className="content-panel">{kicker&&<small className="panel-kicker">{kicker}</small>}<h2>{title}</h2>{children}</section>;
}

function Empty({text,compact=false}:{text:string;compact?:boolean}) { return <div className={`empty-state ${compact?'compact':''}`}>{text}</div>; }

function TeamKeyStats({title,score,stats,external,side}:{title:string;score:number;stats:PlayerStat[];external?:TeamStat;side:"away"|"home"}) {
  const totalPass=stats.reduce((a,s)=>a+Number(s.passing_yards||0),0);
  const totalRush=stats.reduce((a,s)=>a+Number(s.rushing_yards||0),0);
  const receptions=stats.reduce((a,s)=>a+Number(s.receptions||0),0);
  const total=totalPass+totalRush;
  const totalYards = external?.total_yards ?? (total || '—');
  const passYards = external?.net_passing_yards ?? (totalPass || '—');
  const rushYards = external?.rushing_yards ?? (totalRush || '—');
  const firstDowns = external?.first_downs ?? '—';
  return <div className={`team-key-card ${side}`}><div className="team-key-heading"><span className="key-team-chip">{title.split(" ")[0]}</span><b>{title}</b></div><div className="key-stats"><span><small>PTS</small><b>{score}</b></span><span><small>TOTAL YDS</small><b>{totalYards}</b></span><span><small>PASS YDS</small><b>{passYards}</b></span><span><small>RUSH YDS</small><b>{rushYards}</b></span><span><small>1ST DOWNS</small><b>{firstDowns || receptions || '—'}</b></span></div></div>;
}
