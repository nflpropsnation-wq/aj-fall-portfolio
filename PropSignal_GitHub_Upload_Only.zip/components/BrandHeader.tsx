import Link from "next/link";

export default function BrandHeader({active="home"}:{active?:"home"|"games"|"props"|"projections"|"insights"}) {
  return (
    <header className="ps-topbar">
      <div className="ps-topbar-inner">
        <Link className="ps-brand-link" href="/" aria-label="PropSignal home">
          <img src="/brand/propsignal-logo.jpg" alt="PropSignal" />
        </Link>
        <nav className="ps-main-nav" aria-label="Primary">
          <Link className={active==="home"?"active":""} href="/">NFL Prop Bets</Link>
          <Link className={active==="props"?"active":""} href="/#props">Player Props</Link>
          <Link href="/#props">Today&apos;s Props</Link>
          <Link className={active==="games"?"active":""} href="/games">Games</Link>
          <Link href="/#research">Analyzer</Link>
          <Link href="/#methodology">Methodology</Link>
        </nav>
        <div className="ps-header-actions">
          <button className="ps-icon-button" aria-label="Search">⌕</button>
          <button className="ps-login-button">Log In</button>
          <button className="ps-signup-button">Sign Up</button>
        </div>
      </div>
    </header>
  );
}
