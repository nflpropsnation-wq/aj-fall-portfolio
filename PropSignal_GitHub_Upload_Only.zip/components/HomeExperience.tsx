"use client";

import Link from "next/link";
import { useEffect, useMemo, useState } from "react";
import BrandHeader from "@/components/BrandHeader";
import { supabase } from "@/lib/supabase";
import { PropEdge, sampleProps, slugifyPlayer } from "@/lib/props";
import { getTeam } from "@/lib/teamColors";

type ScoreGame = {
  game_id: string;
  kickoff: string;
  game_state: string;
  away_abbreviation: string;
  home_abbreviation: string;
  away_score: number;
  home_score: number;
  broadcast?: string | null;
  away_primary_color?: string | null;
  home_primary_color?: string | null;
  status_detail?: string | null;
};

const demoGames: ScoreGame[] = [
  {game_id:"demo-kc-mia",kickoff:"2026-09-27T17:00:00Z",game_state:"upcoming",away_abbreviation:"KC",home_abbreviation:"MIA",away_score:0,home_score:0,broadcast:"CBS"},
  {game_id:"demo-cin-pit",kickoff:"2026-09-27T17:00:00Z",game_state:"upcoming",away_abbreviation:"CIN",home_abbreviation:"PIT",away_score:0,home_score:0,broadcast:"CBS"},
  {game_id:"demo-lac-buf",kickoff:"2026-09-27T17:00:00Z",game_state:"upcoming",away_abbreviation:"LAC",home_abbreviation:"BUF",away_score:0,home_score:0,broadcast:"CBS"},
  {game_id:"demo-bal-dal",kickoff:"2026-09-27T20:25:00Z",game_state:"upcoming",away_abbreviation:"BAL",home_abbreviation:"DAL",away_score:0,home_score:0,broadcast:"FOX"},
  {game_id:"demo-la-den",kickoff:"2026-09-28T00:20:00Z",game_state:"upcoming",away_abbreviation:"LA",home_abbreviation:"DEN",away_score:0,home_score:0,broadcast:"NBC"},
];

function timeLabel(value:string) {
  const date = new Date(value);
  if (Number.isNaN(date.getTime())) return "TBD";
  return new Intl.DateTimeFormat("en-US",{hour:"numeric",minute:"2-digit",timeZone:"America/New_York"}).format(date)+" ET";
}

function marketTone(market:string) {
  const m=market.toLowerCase();
  if(m.includes("rushing")) return "rush";
  if(m.includes("reception") && !m.includes("yard")) return "receptions";
  if(m.includes("touchdown") || m.includes("td")) return "td";
  if(m.includes("receiv")) return "receiving";
  return "passing";
}

function SignalBars({count=5}:{count?:number}) {
  return <span className="home-signal-bars" aria-hidden="true">{Array.from({length:5}).map((_,i)=><i key={i} className={i<count?"active":""}/>)}</span>;
}

function PlayerImage({prop}:{prop:PropEdge}) {
  const [bad,setBad]=useState(false);
  const color=getTeam(prop.team_abbreviation).primary;
  if(!prop.image_url || bad) return <div className="home-player-fallback" style={{background:`radial-gradient(circle at 50% 22%, color-mix(in srgb, ${color} 66%, white), ${color} 45%, #07131f 76%)`}}><span>{prop.player_name.split(" ").map(x=>x[0]).slice(0,2).join("")}</span></div>;
  return <img src={prop.image_url} alt={prop.player_name} onError={()=>setBad(true)} loading="lazy" referrerPolicy="no-referrer"/>;
}

export default function HomeExperience() {
  const [props,setProps]=useState<PropEdge[]>(sampleProps.slice(0,6));
  const [games,setGames]=useState<ScoreGame[]>(demoGames);
  const [dataLabel,setDataLabel]=useState("Preview data");

  useEffect(()=>{
    let active=true;
    Promise.allSettled([
      supabase.from("current_prop_edges").select("player_id,player_name,position,jersey,image_url,team_abbreviation,team_name,game_id,kickoff,opponent_abbreviation,opponent_name,market,projection_value,sportsbook_line,edge,signed_edge,direction,input_count,agreement_score,signal_category").eq("is_fresh",true).order("edge",{ascending:false}).limit(6),
      fetch("/api/nfl/scoreboard",{cache:"no-store"}).then(r=>r.ok?r.json():Promise.reject(new Error("scoreboard")))
    ]).then(([propResult,gameResult])=>{
      if(!active)return;
      if(propResult.status==="fulfilled" && !propResult.value.error && propResult.value.data?.length){
        setProps(propResult.value.data.map((x:any)=>({...x,projection_value:Number(x.projection_value),sportsbook_line:Number(x.sportsbook_line),edge:Number(x.edge)})) as PropEdge[]);
        setDataLabel("Live PropSignal board");
      }
      if(gameResult.status==="fulfilled" && gameResult.value?.games?.length){
        setGames(gameResult.value.games.slice(0,5));
      }
    });
    return()=>{active=false};
  },[]);

  const featured=props[0] || sampleProps[0];
  const marketCards=useMemo(()=>[
    {key:"Passing Yards",tone:"passing",icon:"◔",copy:"Quarterback passing markets"},
    {key:"Rushing Yards",tone:"rush",icon:"↗",copy:"Running back rushing markets"},
    {key:"Receiving Yards",tone:"receiving",icon:"▤",copy:"Wide receiver + tight end yards"},
    {key:"Receptions",tone:"receptions",icon:"◫",copy:"Catch-volume markets"},
    {key:"Touchdowns",tone:"td",icon:"✦",copy:"Anytime scoring markets"},
  ],[]);

  return <main className="home-app">
    <BrandHeader active="home"/>

    <section className="approved-hero">
      <div className="approved-hero-image" aria-hidden="true"/>
      <div className="approved-hero-shade" aria-hidden="true"/>
      <div className="approved-hero-inner">
        <div className="approved-hero-copy">
          <div className="home-kicker"><img src="/brand/propsignal-icon.jpg" alt=""/> NFL PLAYER PROP PROJECTIONS</div>
          <h1>See the Line.<br/><em>Measure the Edge.</em></h1>
          <p>PropSignal compares sportsbook lines with NFL player projections, matchup data and recent performance to identify where our projected numbers differ from the market.</p>
          <div className="hero-cta-row">
            <a className="hero-cta primary" href="#props">VIEW TODAY&apos;S NFL PROP BETS <span>→</span></a>
            <Link className="hero-cta secondary" href="/games">OPEN LIVE GAME CENTER <span>→</span></Link>
          </div>
          <div className="hero-proof-row">
            <span>◉ Consensus Projections</span><span>◷ Real-Time Lines</span><span>⌁ Matchup Intelligence</span><span>◴ Live Game Tracking</span>
          </div>
        </div>

        <Link href={`/players/${slugifyPlayer(featured.player_name)}`} className="hero-edge-card">
          <div className="hero-edge-top"><div><strong>{featured.player_name}</strong><small>{featured.market.toUpperCase()}</small></div><span className="hero-team-mark">{featured.team_abbreviation}</span></div>
          <div className="hero-edge-numbers"><span><small>SPORTSBOOK</small><b>{featured.sportsbook_line}</b></span><span><small>PROPSIGNAL</small><b>{featured.projection_value}</b></span></div>
          <div className="hero-edge-bottom"><span className="hero-edge-box"><small>EDGE</small><b>+{featured.edge.toFixed(1)}</b><em>{featured.signal_category || "Strong"}</em></span><span className="hero-signal"><SignalBars/><em>{featured.signal_category || "Strong"} Signal</em></span></div>
        </Link>
      </div>
    </section>

    <div className="home-content-shell">
      <section className="home-section" id="props">
        <div className="home-section-title"><div><h2>Today&apos;s Top NFL Prop Projections</h2><small>{dataLabel}</small></div><a href="#research">View All Today&apos;s Props →</a></div>
        <div className="approved-prop-grid">
          {props.slice(0,6).map((prop,i)=><Link key={`${prop.player_name}-${prop.market}-${i}`} href={`/players/${slugifyPlayer(prop.player_name)}`} className="approved-prop-card">
            <div className="approved-prop-photo"><PlayerImage prop={prop}/><span className="approved-team-badge" style={{background:getTeam(prop.team_abbreviation).primary}}>{prop.team_abbreviation}</span></div>
            <div className="approved-prop-card-body">
              <strong>{prop.player_name}</strong><small>{prop.market.toUpperCase()}</small>
              <div className="approved-prop-values"><span><em>SPORTSBOOK</em><b>{prop.sportsbook_line}</b></span><span><em>PROPSIGNAL</em><b>{prop.projection_value}</b></span></div>
              <div className="approved-prop-edge"><span><em>EDGE</em><b>+{prop.edge.toFixed(1)}</b></span><SignalBars/></div>
              <div className="approved-prop-signal">{prop.signal_category || "Strong"} Signal</div>
            </div>
          </Link>)}
        </div>
      </section>

      <section className="home-section market-section">
        <div className="home-section-title"><h2>NFL Player Props by Market</h2><a href="#props">View All Markets →</a></div>
        <div className="approved-market-grid">
          {marketCards.map(card=><a href="#props" key={card.key} className={`approved-market-card ${card.tone}`}><div className="market-photo-sheen"/><div className="market-card-bottom"><span className="market-round-icon">{card.icon}</span><strong>{card.key}</strong><i>→</i></div></a>)}
        </div>
      </section>

      <section className="home-section" id="games">
        <div className="home-section-title"><h2>Today&apos;s NFL Games</h2><Link href="/games">View Full Schedule →</Link></div>
        <div className="approved-games-grid">
          {games.slice(0,5).map(game=>{
            const away=getTeam(game.away_abbreviation),home=getTeam(game.home_abbreviation);
            const query=encodeURIComponent(game.game_id);
            return <Link href={`/games?game=${query}`} key={game.game_id} className="approved-game-card">
              <div className="approved-game-time">{game.game_state==="live"?<b className="home-live-badge">LIVE</b>:timeLabel(game.kickoff)}</div>
              <div className="approved-game-match"><span className="home-team-dot" style={{background:game.away_primary_color||away.primary}}>{game.away_abbreviation}</span><b>{game.away_abbreviation} @ {game.home_abbreviation}</b><span className="home-team-dot" style={{background:game.home_primary_color||home.primary}}>{game.home_abbreviation}</span></div>
              <div className="approved-game-sub">{game.game_state==="live"?`${game.away_score} - ${game.home_score}`:(game.broadcast || "Game Center")} <span>→</span></div>
            </Link>
          })}
        </div>
      </section>

      <section className="home-section" id="methodology">
        <div className="home-section-title"><h2>How PropSignal Finds the Edge</h2></div>
        <div className="approved-method-grid">
          <article><i>▤</i><strong>Sportsbook Line</strong><p>Current market lines from top sportsbooks.</p></article>
          <article><i>▥</i><strong>Projection Consensus</strong><p>Multiple projection sources aggregated.</p></article>
          <article><i>▦</i><strong>Matchup + DVOA + Form</strong><p>Opponent data, defensive metrics and recent performance.</p></article>
          <article><i>▇</i><strong>PropSignal Edge</strong><p>Identify where our projected numbers differ from the market.</p></article>
        </div>
      </section>

      <section className="home-section">
        <div className="home-section-title"><h2>Why PropSignal</h2></div>
        <div className="approved-info-grid">
          <article><span className="approved-info-icon blue">◉</span><div><strong>Consensus Projections</strong><p>Multiple projection sources for more accurate numbers.</p></div></article>
          <article><span className="approved-info-icon green">▤</span><div><strong>Sportsbook Lines</strong><p>Compare market lines across top sportsbooks.</p></div></article>
          <article><span className="approved-info-icon purple">⌁</span><div><strong>Matchup Intelligence</strong><p>DVOA, coverage and opponent tendencies.</p></div></article>
          <article><span className="approved-info-icon gold">◴</span><div><strong>Live Game Center</strong><p>Follow player performance during games.</p></div></article>
        </div>
      </section>

      <section className="home-section" id="research">
        <div className="home-section-title"><h2>NFL Prop Bet Research</h2><a href="#faq">View All Resources →</a></div>
        <div className="approved-info-grid research">
          <article><span className="approved-info-icon blue">▦</span><div><strong>NFL Prop Bets Today</strong><p>Today&apos;s top player props and best edges.</p></div></article>
          <article><span className="approved-info-icon green">♟</span><div><strong>NFL Player Props</strong><p>Explore all player props by market and game.</p></div></article>
          <article><span className="approved-info-icon purple">▥</span><div><strong>NFL Prop Predictions</strong><p>Data-driven projections and analysis.</p></div></article>
          <article><span className="approved-info-icon gold">▤</span><div><strong>NFL Prop Bet Analyzer</strong><p>Compare any player prop and see the edge.</p></div></article>
        </div>
      </section>

      <section className="home-section faq-section" id="faq">
        <div className="home-section-title"><h2>Frequently Asked Questions</h2><a href="#faq">View All FAQs →</a></div>
        <div className="home-faq-grid">
          <Faq question="What is a prop bet in football?">A prop bet focuses on a specific player or game outcome, such as passing yards, rushing yards, receptions or touchdowns.</Faq>
          <Faq question="How do NFL player props work?">Sportsbooks set a statistical line and price. PropSignal compares that market number with its projection and matchup context.</Faq>
          <Faq question="When do NFL player props come out?">Markets typically appear during the week and move as injuries, depth charts and betting activity change.</Faq>
          <Faq question="How does PropSignal calculate its projections?">PropSignal blends projection inputs with matchup data, role, recent performance and defensive context.</Faq>
          <Faq question="What does the PropSignal Edge mean?">The Edge is the difference between the current sportsbook line and the PropSignal projection.</Faq>
        </div>
      </section>
    </div>
  </main>;
}

function Faq({question,children}:{question:string;children:React.ReactNode}) {
  const [open,setOpen]=useState(false);
  return <button className={`home-faq ${open?"open":""}`} onClick={()=>setOpen(x=>!x)} aria-expanded={open}><span className="faq-question">{question}<b>{open?"−":"⌄"}</b></span>{open&&<span className="faq-answer">{children}</span>}</button>;
}
