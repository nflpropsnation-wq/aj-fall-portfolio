"use client";

import Link from "next/link";
import { useEffect, useMemo, useState } from "react";
import BrandHeader from "@/components/BrandHeader";
import { supabase } from "@/lib/supabase";
import { playerDetails, PropEdge, sampleProps, slugifyPlayer } from "@/lib/props";
import { getTeam } from "@/lib/teamColors";

type RecentGame = {
  week?: number;
  season?: number;
  opponent?: string;
  rec_yds?: number;
  rush_yds?: number;
  pass_yds?: number;
  receptions?: number;
  passing_tds?: number;
  touchdowns?: number;
};

type MatchupRow = {
  team_abbr?: string;
  vs_wr_rank?: number | null;
  vs_te_rank?: number | null;
  vs_rb_rank?: number | null;
  pass_def_rank?: number | null;
  rush_def_rank?: number | null;
  vs_wr_percentile?: number | null;
  vs_te_percentile?: number | null;
  vs_rb_percentile?: number | null;
  pass_def_percentile?: number | null;
  rush_def_percentile?: number | null;
};

function fallbackFor(slug:string) {
  return sampleProps.find(p=>slugifyPlayer(p.player_name)===slug) || sampleProps.find(p=>p.player_name==="Ja'Marr Chase") || sampleProps[0];
}

function marketFamily(market:string) {
  const m=market.toLowerCase();
  if(m.includes("passing") && m.includes("yard")) return "passing";
  if(m.includes("rushing") && m.includes("yard")) return "rushing";
  if(m.includes("reception") && !m.includes("yard")) return "receptions";
  if(m.includes("touchdown") || m.includes("td")) return "touchdowns";
  return "receiving";
}

function valueForGame(game:RecentGame, market:string) {
  switch(marketFamily(market)) {
    case "passing": return Number(game.pass_yds || 0);
    case "rushing": return Number(game.rush_yds || 0);
    case "receptions": return Number(game.receptions || 0);
    case "touchdowns": return Number(game.touchdowns ?? game.passing_tds ?? 0);
    default: return Number(game.rec_yds || 0);
  }
}

function shortMarket(market:string) {
  return market.replace(/_/g," ").replace(/\b\w/g,c=>c.toUpperCase());
}

function gradeFromRank(rank:number) {
  if(rank>=29) return "A";
  if(rank>=25) return "A-";
  if(rank>=21) return "B+";
  if(rank>=17) return "B";
  if(rank>=13) return "B-";
  if(rank>=9) return "C+";
  return "C";
}

function edgePct(prop:PropEdge) {
  if(!prop.sportsbook_line) return 0;
  return (prop.edge / Math.abs(prop.sportsbook_line))*100;
}

function PlayerHeroImage({prop}:{prop:PropEdge}) {
  const [bad,setBad]=useState(false);
  const team=getTeam(prop.team_abbreviation);
  if(!prop.image_url || bad) return <div className="player-detail-fallback" style={{background:`radial-gradient(circle at 50% 20%, color-mix(in srgb, ${team.primary} 60%, white), ${team.primary} 44%, #06131e 78%)`}}><span>{prop.player_name.split(" ").map(x=>x[0]).slice(0,2).join("")}</span></div>;
  return <img src={prop.image_url} alt={prop.player_name} onError={()=>setBad(true)} referrerPolicy="no-referrer"/>;
}

export default function PlayerDetail({slug}:{slug:string}) {
  const fallback=fallbackFor(slug);
  const [props,setProps]=useState<PropEdge[]>([fallback]);
  const [activeMarket,setActiveMarket]=useState(fallback.market);
  const [recent,setRecent]=useState<RecentGame[]>([]);
  const [matchup,setMatchup]=useState<MatchupRow|null>(null);
  const [favorite,setFavorite]=useState(false);
  const [dataSource,setDataSource]=useState("Preview model");

  useEffect(()=>{
    let mounted=true;
    supabase.from("current_prop_edges").select("player_id,player_name,position,jersey,image_url,team_abbreviation,team_name,game_id,kickoff,opponent_abbreviation,opponent_name,market,projection_value,sportsbook_line,edge,signed_edge,direction,input_count,agreement_score,signal_category").limit(250).then(async(result:any)=>{
      const {data}=result;
      if(!mounted)return;
      const rows=((data||[]) as any[]).map(x=>({...x,projection_value:Number(x.projection_value),sportsbook_line:Number(x.sportsbook_line),edge:Number(x.edge)})) as PropEdge[];
      const matching=rows.filter(p=>slugifyPlayer(p.player_name)===slug);
      const liveProp=matching[0];
      const base=liveProp || fallback;
      if(matching.length){setProps(matching);setActiveMarket(matching[0].market);setDataSource("Live PropSignal board");}

      const [logsResult,matchupResult]=await Promise.all([
        supabase.from("player_recent_logs").select("games").eq("player_name",base.player_name).maybeSingle(),
        supabase.from("matchup_ratings").select("team_abbr,vs_wr_rank,vs_te_rank,vs_rb_rank,pass_def_rank,rush_def_rank,vs_wr_percentile,vs_te_percentile,vs_rb_percentile,pass_def_percentile,rush_def_percentile").eq("team_abbr",base.opponent_abbreviation).order("season",{ascending:false}).limit(1).maybeSingle(),
      ]);
      if(!mounted)return;
      if(logsResult.data?.games && Array.isArray(logsResult.data.games)) setRecent(logsResult.data.games.slice(0,5) as RecentGame[]);
      if(matchupResult.data) setMatchup(matchupResult.data as MatchupRow);
    });
    return()=>{mounted=false};
  },[slug]);

  const prop=props.find(p=>p.market===activeMarket) || props[0] || fallback;
  const family=marketFamily(prop.market);
  const defaultDetails=playerDetails[slug] || {
    matchupGrade:"B+",defenseRank:22,dvoa:8.4,paceRank:14,recent:[82,91,64,101,88],opponents:["W1","W2","W3","W4","W5"],targetShare:"24%",targetsPerGame:"8.6",yardsPerRoute:"2.12",airYards:"89.7",take:`${prop.player_name} shows a positive gap between the PropSignal projection and the current market line. Matchup and recent usage support the current signal.`
  };

  const matchupRank=useMemo(()=>{
    if(!matchup) return defaultDetails.defenseRank;
    if(family==="rushing") return Number(matchup.vs_rb_rank || matchup.rush_def_rank || defaultDetails.defenseRank);
    if(family==="passing") return Number(matchup.pass_def_rank || defaultDetails.defenseRank);
    if(prop.position==="TE") return Number(matchup.vs_te_rank || matchup.pass_def_rank || defaultDetails.defenseRank);
    return Number(matchup.vs_wr_rank || matchup.pass_def_rank || defaultDetails.defenseRank);
  },[matchup,family,prop.position,defaultDetails.defenseRank]);

  const recentValues=recent.length?recent.map(g=>valueForGame(g,prop.market)):defaultDetails.recent;
  const recentOpps=recent.length?recent.map(g=>g.opponent || `W${g.week || ""}`):defaultDetails.opponents;
  const maxValue=Math.max(prop.sportsbook_line,...recentValues,1)*1.15;
  const average=recentValues.length?recentValues.reduce((a,b)=>a+b,0)/recentValues.length:0;
  const cleared=recentValues.filter(v=>prop.direction.toLowerCase()==="under"?v<prop.sportsbook_line:v>prop.sportsbook_line).length;
  const grade=matchup?gradeFromRank(matchupRank):defaultDetails.matchupGrade;
  const team=getTeam(prop.team_abbreviation);
  const opp=getTeam(prop.opponent_abbreviation);

  return <main className="player-detail-app" style={{"--player-team":team.primary,"--player-team2":team.secondary,"--player-opp":opp.primary} as React.CSSProperties}>
    <BrandHeader active="props"/>
    <div className="player-detail-shell">
      <div className="player-breadcrumb"><Link href="/">← Home</Link><span>/</span><a href="/#props">Player Props</a><span>/</span><strong>{prop.player_name}</strong><em>{dataSource}</em></div>

      <section className="player-detail-card">
        <div className="player-detail-top">
          <div className="player-portrait-panel">
            <div className="player-detail-photo"><PlayerHeroImage prop={prop}/></div>
          </div>
          <div className="player-detail-heading">
            <button className={`detail-favorite ${favorite?"on":""}`} onClick={()=>setFavorite(x=>!x)} aria-label="Favorite player">{favorite?"♥":"♡"}</button>
            <div className="detail-brand"><img src="/brand/propsignal-icon.jpg" alt=""/><span>NFL PLAYER PROPS</span></div>
            <h1>{prop.player_name}</h1>
            <div className="detail-meta"><b>{prop.position}</b><i>•</i><b>{prop.team_abbreviation}</b>{prop.jersey&&<><i>•</i><b>#{prop.jersey}</b></>}<i>•</i><span>vs {prop.opponent_abbreviation}</span></div>
            <div className="detail-matchup-row"><span className="detail-team-pill" style={{background:team.primary}}>{prop.team_abbreviation}</span><b>VS</b><span className="detail-team-pill" style={{background:opp.primary}}>{prop.opponent_abbreviation}</span><small>{prop.kickoff?new Date(prop.kickoff).toLocaleString("en-US",{weekday:"short",hour:"numeric",minute:"2-digit"}):"Upcoming"}</small></div>
          </div>
        </div>

        <div className="detail-market-tabs">
          {(props.length>1?props:marketFallbacks(prop)).slice(0,4).map((p,i)=><button key={`${p.market}-${i}`} className={p.market===activeMarket?"active":""} onClick={()=>{setActiveMarket(p.market);if(props.length===1&&p.market!==props[0].market)setProps(marketFallbacks(prop));}}>{shortMarket(p.market)}</button>)}
        </div>

        <div className="detail-big-three">
          <article className="detail-number-card line"><small>LINE</small><strong>{prop.sportsbook_line}</strong><span>{prop.direction.toUpperCase()}</span></article>
          <article className="detail-number-card projection"><small>PROJECTION</small><strong>{prop.projection_value}</strong><span>PROPSIGNAL</span></article>
          <article className="detail-number-card edge"><small>EDGE</small><strong>{prop.edge>=0?"+":""}{prop.edge.toFixed(1)}</strong><span>{edgePct(prop)>=0?"+":""}{edgePct(prop).toFixed(1)}%</span></article>
        </div>

        <div className="detail-intel-grid">
          <article><small>MATCHUP GRADE</small><strong className="positive">{grade}</strong></article>
          <article><small>{prop.opponent_abbreviation} {family==="rushing"?"RUSH":"PASS"} DEF RANK</small><strong className="negative">{matchupRank}th</strong></article>
          <article><small>DVOA vs {prop.position}</small><strong className="negative">+{defaultDetails.dvoa.toFixed(1)}%</strong><span>WORSE THAN AVG</span></article>
          <article><small>PACE RANK</small><strong className="positive">{defaultDetails.paceRank}th</strong></article>
        </div>

        <section className="detail-last-five">
          <div className="detail-section-head"><h2>Last 5 Games <span>({shortMarket(prop.market)})</span></h2><b>AVG {average.toFixed(1)}</b></div>
          <div className="detail-chart">
            <div className="detail-line-marker" style={{bottom:`${Math.max(12,Math.min(84,(prop.sportsbook_line/maxValue)*100))}%`}}><span>{prop.sportsbook_line}</span></div>
            {recentValues.map((v,i)=><div className="detail-chart-col" key={`${v}-${i}`}><div className={`detail-bar ${prop.direction.toLowerCase()==="under"?(v<prop.sportsbook_line?"clear":"miss"):(v>prop.sportsbook_line?"clear":"miss")}`} style={{height:`${Math.max(9,(v/maxValue)*100)}%`}}><b>{v}</b></div><small>vs {recentOpps[i] || "—"}</small></div>)}
          </div>
        </section>

        <div className="detail-support-grid">
          <article><small>TARGET SHARE</small><strong>{defaultDetails.targetShare}</strong></article>
          <article><small>TARGETS/GAME</small><strong>{defaultDetails.targetsPerGame}</strong></article>
          <article><small>YARDS/ROUTE</small><strong>{defaultDetails.yardsPerRoute}</strong></article>
          <article><small>AIR YARDS</small><strong>{defaultDetails.airYards}</strong></article>
        </div>

        <section className="propsignal-take"><div className="take-icon">ϟ</div><div><h2>PropSignal Take</h2><p>{cleared?`${prop.player_name} has cleared this line in ${cleared} of the last ${recentValues.length}. `:""}{defaultDetails.take}</p></div><span>›</span></section>
      </section>

      <div className="detail-footer-actions"><Link href="/#props">← Back to Today&apos;s Props</Link><Link href="/games">Open Live Game Center →</Link></div>
    </div>
  </main>;
}

function marketFallbacks(base:PropEdge):PropEdge[] {
  const family=marketFamily(base.market);
  if(family==="rushing") return [
    base,
    {...base,market:"Receiving Yards",sportsbook_line:34.5,projection_value:42.8,edge:8.3},
    {...base,market:"Receptions",sportsbook_line:4.5,projection_value:5.7,edge:1.2},
    {...base,market:"Anytime TD",sportsbook_line:.5,projection_value:.74,edge:.24},
  ];
  if(family==="passing") return [
    base,
    {...base,market:"Passing Touchdowns",sportsbook_line:1.5,projection_value:2.2,edge:.7},
    {...base,market:"Rushing Yards",sportsbook_line:36.5,projection_value:44.4,edge:7.9},
    {...base,market:"Anytime TD",sportsbook_line:.5,projection_value:.59,edge:.09},
  ];
  return [
    base,
    {...base,market:"Receptions",sportsbook_line:6.5,projection_value:8.1,edge:1.6},
    {...base,market:"Anytime TD",sportsbook_line:.5,projection_value:.72,edge:.22},
  ];
}
